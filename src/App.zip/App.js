import logo from './logo.svg';
import './App.css';


function App() {
  return (
    <div className="App">
      <div className="split1" id="div1">div1
      </div>
      <div className="split2" id="div2">div2
      </div>
      <div className="split3" id="div3">div3
      </div>
      {/* <div className="split" id="div4">div4
      </div> */}
    </div>
  );
}

export default App;
